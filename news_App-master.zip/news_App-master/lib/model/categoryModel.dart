class CategoryModel {
   String imgPath;
   String label;

   CategoryModel({
   required this.imgPath,
   required this.label,
});
}